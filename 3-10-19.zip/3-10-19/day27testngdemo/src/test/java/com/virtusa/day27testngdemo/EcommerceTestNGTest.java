package com.virtusa.day27testngdemo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;




public class EcommerceTestNGTest
{
	private WebDriver webDriver;
	
	@BeforeClass
	public void setEnvironment()
	{
		 System.setProperty("webdriver.chrome.driver","D:\\JP\\Chrome_Driver\\chromedriver.exe");//Enter Chrome driver path here
		 webDriver=new ChromeDriver();
	        
	}
	
	
	
	
	
		
	  @Test(dataProvider="credentials")
	  public void testTest(String userName,String password)
	  {
		  webDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		  webDriver.get("http://localhost:7070/day14springmvcjpashopping");
	  
		  webDriver.findElement(By.id("username")).sendKeys(userName);
		  webDriver.findElement(By.id("password")).sendKeys(password);
		  webDriver.findElement(By.xpath("/html/body/section[2]/form/fieldset/button")).click(); 
	  }
	 
  
  @DataProvider(name="credentials")
	public Object[][] dataDrivenTest()
	{
	  Object[][] dataProvider=null;
		try {
			dataProvider=getData("D:\\Akshay\\Spring_Projects\\day27testngdemo","data.xlsx","Sheet1");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dataProvider;
	}
	
 /* @Test
  public void gmailLoginTest()
  {
	 // webDriver.manage().timeouts().implicitlyWait(2,  TimeUnit.SECONDS);
	  webDriver.get("https://accounts.google.com/signin/v2/identifier?continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&service=mail&sacu=1&rip=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin");
      
      webDriver.findElement(By.name("identifier")).sendKeys("akshay@gmail.com");//email address
      webDriver.findElement(By.xpath("//*[@id=\"identifierNext\"]/span/span")).click();//next button
      
     //webDriver.findElement(By.name("password")).sendKeys("admin123");//password
      //webDriver.findElement(By.xpath("//*[@id=\"yDmH0d\"]")).sendKeys("abc123546");
    //  webDriver.findElement(By.xpath("//*[@id=\"passwordNext\"]/span")).click();//next button
      
      
      
  }*/
  
  
  public static String[][] getData(String filePath,String fileName,String sheetName) throws IOException
  {
	  File file=new File(filePath+"\\"+fileName);
		
		FileInputStream inputStream=new FileInputStream(file);
		//DataFormatter dataFormatter = null ;
		Workbook workBook=null;
		
		String fileExtensionName=fileName.substring(fileName.indexOf("."));
		
		if(fileExtensionName.equals(".xlsx")) {
			workBook = new XSSFWorkbook(inputStream);
		}
		else if(fileExtensionName.equals(".xls")) {
			workBook = new HSSFWorkbook(inputStream);
		}
		
		Sheet sheet=workBook.getSheet(sheetName);
		
		int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
		
		
		//String categoryName = null;
		
		String[][] data=new String[rowCount+1][sheet.getRow(0).getLastCellNum()];
		
		for(int i=0;i<rowCount+1;i++)
		{
			Row row=sheet.getRow(i);
			
			for(int j=0;j<row.getLastCellNum();j++) 
			{
				if(row.getCell(j).getCellType().equals(CellType.STRING))
				{
					System.out.print(i+" "+row.getCell(j).getStringCellValue()+"||");
					
					data[i][j]=row.getCell(j).getStringCellValue();
						
				}
			}
			System.out.println();
			
		}
	
	return data;
	  
  }
  
  

  @AfterClass
  public void afterMethod()
  {
	  webDriver.quit();
  }
  
  
}
