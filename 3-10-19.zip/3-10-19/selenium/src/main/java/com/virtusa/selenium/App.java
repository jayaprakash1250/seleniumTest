package com.virtusa.selenium;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Hashtable;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.virtusa.selenium.models.Product;

/**
 * Test Web Driver
 *
 */
public class App 
{
	
	
	public static Hashtable<Product,String> readExcel(String filePath,String fileName,String sheetName) throws IOException
	{
		File file=new File(filePath+"\\"+fileName);
		
		FileInputStream inputStream=new FileInputStream(file);
		DataFormatter dataFormatter = null ;
		Workbook workBook=null;
		
		String fileExtensionName=fileName.substring(fileName.indexOf("."));
		
		if(fileExtensionName.equals(".xlsx")) {
			workBook = new XSSFWorkbook(inputStream);
		}
		else if(fileExtensionName.equals(".xls")) {
			workBook = new HSSFWorkbook(inputStream);
		}
		
		Sheet sheet=workBook.getSheet(sheetName);
		
		int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
		
		Product product;
		String categoryName = null;
		Hashtable<Product,String> hashTable=new Hashtable<Product,String>();
		for(int i=0;i<rowCount+1;i++)
		{
			Row row=sheet.getRow(i);
			product=new Product();
			
			for(int j=0;j<row.getLastCellNum();j++) 
			{
				if(row.getCell(j).getCellType().equals(CellType.STRING))
				{
					System.out.print(i+" "+row.getCell(j).getStringCellValue()+"||");
					
					if(row.getCell(j).getStringCellValue().contains("-"))
						categoryName=row.getCell(j).getStringCellValue();
					else
						product.setProductName(row.getCell(j).getStringCellValue());
					
						
				}
				if(row.getCell(j).getCellType().equals(CellType.NUMERIC))
				{
					System.out.print(i+" "+row.getCell(j).getNumericCellValue()+"||");
					if(!HSSFDateUtil.isCellDateFormatted(row.getCell(j)))
						product.setCost((int)Math.round(row.getCell(j).getNumericCellValue()));
						
					if(HSSFDateUtil.isCellDateFormatted(row.getCell(j)))
					{
						String cellStringValue=new java.sql.Date(row.getCell(j).getDateCellValue().getTime()).toLocalDate().toString();
						System.out.println(cellStringValue);
						product.setDop(LocalDate.parse(cellStringValue,java.time.format.DateTimeFormatter.ISO_LOCAL_DATE));
					}
					
				}
			}
			System.out.println();
			hashTable.put(product, categoryName);
			
		}
		return hashTable;
		
	}
	
	
    public static void main( String[] args ) throws InterruptedException, IOException
    {
    	Hashtable<Product,String> data=readExcel("D:\\JP\\Chrome_Driver","testcase.xlsx","Sheet1");//enter excel sheet path.name.sheet_Number
    	
        System.setProperty("webdriver.chrome.driver","D:\\JP\\Chrome_Driver\\chromedriver.exe");//Enter Chrome driver path here
        System.out.println( "Hello World!" );
        
        WebDriver webDriver=new ChromeDriver();//we are using chrome browser to run test cases
       
        webDriver.get("http://localhost:7070/day14springmvcjpashopping");
        
        webDriver.findElement(By.id("username")).sendKeys("admin");
        webDriver.findElement(By.id("password")).sendKeys("admin");
        webDriver.findElement(By.xpath("/html/body/section[2]/form/fieldset/button")).click();
        
        Actions action = new Actions(webDriver);
		WebElement btn = webDriver.findElement(By.id("product"));
		action.moveToElement(btn).perform();//mouse hover
		webDriver.findElement(By.xpath("/html/body/section/header/article/div[2]/div/a[1]")).click();
		
		
		
		for(Product product:data.keySet())
		{
			webDriver.findElement(By.name("productName")).sendKeys(product.getProductName());
			webDriver.findElement(By.name("cost")).sendKeys(String.valueOf(product.getCost()));
			webDriver.findElement(By.name("dop")).sendKeys(product.getDop().toString());
			Select dropCountry=new Select(webDriver.findElement(By.name("categoryInfo")));
			dropCountry.selectByVisibleText(data.get(product));
			webDriver.findElement(By.xpath("/html/body/form/fieldset/button[1]")).click();
		    
		}
		   
	     webDriver.close();
        
    }
}
